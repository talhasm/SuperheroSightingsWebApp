package com.sg.superherosightings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperherosightingsApplicationTests {

	@Test
	void contextLoads() {
	}

} 
